package com.example.llamachat;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DialogueActivity extends AppCompatActivity {

    private RecyclerView conversationView;
    private EditText inputBox;
    private ImageView sendIcon;
    private ChatAdapter chatAdapter;
    private ArrayList<ChatItem> chatHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialogue);

        conversationView = findViewById(R.id.conversationView);
        inputBox = findViewById(R.id.inputBox);
        sendIcon = findViewById(R.id.sendIcon);

        chatHistory = new ArrayList<>();
        chatAdapter = new ChatAdapter(chatHistory, getIntent().getStringExtra("userName"));
        conversationView.setLayoutManager(new LinearLayoutManager(this));
        conversationView.setAdapter(chatAdapter);

        sendIcon.setOnClickListener(v -> {
            String message = inputBox.getText().toString().trim();
            if (!message.isEmpty()) {
                chatHistory.add(new ChatItem(message, "user"));
                chatAdapter.notifyItemInserted(chatHistory.size() - 1);
                inputBox.setText("");

                BotBridge.askBot(message, reply -> runOnUiThread(() -> {
                    chatHistory.add(new ChatItem(reply, "bot"));
                    chatAdapter.notifyItemInserted(chatHistory.size() - 1);
                    conversationView.scrollToPosition(chatHistory.size() - 1);
                }));
            }
        });
    }
}
