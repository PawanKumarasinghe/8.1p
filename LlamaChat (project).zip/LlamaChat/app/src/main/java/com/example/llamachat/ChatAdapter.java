package com.example.llamachat;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.*;
import android.widget.TextView;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<ChatItem> chatItems;
    private final String user;

    public ChatAdapter(List<ChatItem> chatItems, String user) {
        this.chatItems = chatItems;
        this.user = user;
    }

    private static final int TYPE_USER = 0;
    private static final int TYPE_BOT = 1;

    @Override
    public int getItemViewType(int position) {
        return chatItems.get(position).getSender().equals("user") ? TYPE_USER : TYPE_BOT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = viewType == TYPE_USER ? R.layout.item_user_msg : R.layout.item_bot_msg;
        View view = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        return new ChatHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ChatHolder) holder).bind(chatItems.get(position));
    }

    @Override
    public int getItemCount() {
        return chatItems.size();
    }

    static class ChatHolder extends RecyclerView.ViewHolder {
        private final TextView msgText;

        public ChatHolder(View itemView) {
            super(itemView);
            msgText = itemView.findViewById(R.id.messageText);
        }

        void bind(ChatItem item) {
            msgText.setText(item.getContent());
        }
    }
}
