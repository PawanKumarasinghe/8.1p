package com.example.llamachat;

public class ChatItem {
    private String content;
    private String sender;  // "user" or "bot"

    public ChatItem(String content, String sender) {
        this.content = content;
        this.sender = sender;
    }

    public String getContent() {
        return content;
    }

    public String getSender() {
        return sender;
    }
}
