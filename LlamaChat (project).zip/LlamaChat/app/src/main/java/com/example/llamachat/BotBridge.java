package com.example.llamachat;

import java.util.Arrays;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.*;
import retrofit2.converter.gson.GsonConverterFactory;

public class BotBridge {

    private static final String AUTH_KEY = "1ea775a7-4e7d-47bf-b646-f18e28075d58";

    private static final TalkService talkService;

    static {
        OkHttpClient okClient = new OkHttpClient.Builder()
                .addInterceptor((Interceptor.Chain chain) -> {
                    Request base = chain.request();
                    Request decorated = base.newBuilder()
                            .addHeader("Authorization", "Bearer " + AUTH_KEY)
                            .addHeader("Content-Type", "application/json")
                            .method(base.method(), base.body())
                            .build();
                    return chain.proceed(decorated);
                })
                .build();

        Retrofit retro = new Retrofit.Builder()
                .baseUrl("https://api.llama-api.com/")
                .client(okClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        talkService = retro.create(TalkService.class);
    }

    public static void askBot(String query, BotReply callback) {
        ChatPrompt.Message sys = new ChatPrompt.Message("system", "You are a mobile assistant.");
        ChatPrompt.Message usr = new ChatPrompt.Message("user", query);

        ChatPrompt payload = new ChatPrompt("llama3.1-70b", Arrays.asList(sys, usr), false);

        talkService.getReply(payload).enqueue(new Callback<ChatResponse>() {
            @Override
            public void onResponse(Call<ChatResponse> call, Response<ChatResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onReply(response.body().getAnswer());
                } else {
                    callback.onReply("❌ Bot failed.");
                }
            }

            @Override
            public void onFailure(Call<ChatResponse> call, Throwable t) {
                callback.onReply("❌ No connection.");
            }
        });
    }

    public interface BotReply {
        void onReply(String replyText);
    }
}
