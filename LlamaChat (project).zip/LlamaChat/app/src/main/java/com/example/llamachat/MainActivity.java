package com.example.llamachat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText nameField;
    Button enterBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameField = findViewById(R.id.nameField);
        enterBtn = findViewById(R.id.enterBtn);

        enterBtn.setOnClickListener(view -> {
            String enteredName = nameField.getText().toString().trim();
            if (!enteredName.isEmpty()) {
                Intent moveToChat = new Intent(MainActivity.this, DialogueActivity.class);
                moveToChat.putExtra("userName", enteredName);
                startActivity(moveToChat);
            } else {
                Toast.makeText(this, "Username required", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
