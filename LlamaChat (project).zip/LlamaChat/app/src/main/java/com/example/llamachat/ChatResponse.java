package com.example.llamachat;

import java.util.List;

public class ChatResponse {
    public List<Choice> choices;

    public String getAnswer() {
        return choices != null && !choices.isEmpty()
                ? choices.get(0).message.content
                : "⚠ No reply.";
    }

    public static class Choice {
        public Message message;
    }

    public static class Message {
        public String role;
        public String content;
    }
}
