package com.example.llamachat;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface TalkService {
    @POST("chat/completions")
    Call<ChatResponse> getReply(@Body ChatPrompt prompt);
}
